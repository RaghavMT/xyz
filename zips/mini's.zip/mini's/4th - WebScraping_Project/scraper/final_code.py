from bs4 import BeautifulSoup
import requests
import pandas as pd

jobs_data = []

BASE_URL = "https://internshala.com/jobs/work-from-home/page-{}"

for page in range(1, 2):
    print(f"Scraping page {page}...")

    if page == 1:
        url = "https://internshala.com/jobs/"
    else:
        url = BASE_URL.format(page)

    html_text = requests.get(url).text
    soup = BeautifulSoup(html_text, 'lxml')

    jobs = soup.find_all('div', class_='internship_meta experience_meta')

    for job in jobs:
        # Job Title (SAFE)
        title_tag = job.find('a', class_='job-title-href')
        job_title = title_tag.get_text(strip=True) if title_tag else "Not mentioned"

        # Company Name (SAFE)
        company_tag = job.find('p', class_='company-name')
        company_name = company_tag.get_text(strip=True) if company_tag else "Not mentioned"

        # Location (SAFE)
        location_tag = job.find('p', class_='row-1-item locations')
        location = location_tag.get_text(strip=True) if location_tag else "Not mentioned"

        # Salary (SAFE)
        salary_tag = job.find('span', class_='desktop')
        salary = salary_tag.get_text(strip=True) if salary_tag else "Not mentioned"

        # Experience (SAFE)
        row_items = job.find_all('div', class_='row-1-item')
        experience = row_items[1].get_text(strip=True) if len(row_items) > 1 else "Not mentioned"

        # Skills (SAFE)
        skills_div = job.find('div', class_='job_skills')
        skills = (
            [skill.get_text(strip=True) for skill in skills_div.find_all('div', class_='job_skill')]
            if skills_div else []
        )

        jobs_data.append([
            job_title,
            company_name,
            location,
            salary,
            experience,
            skills
        ])
        print(jobs_data)

# Create Excel ONCE
#df = pd.DataFrame(
#    jobs_data,
#    columns=["Job Title", "Company", "Location", "Salary", "Experience", "Skills"]
#)

#df.to_excel("61 to 100_internshala_jobs.xlsx", index=False)

print("Scraping completed. Excel file created successfully.")
