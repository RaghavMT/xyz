import streamlit as st
import joblib

st.set_page_config(page_title="Job Role Predictor", page_icon="💼")

st.title("💼 Job Role Predictor")
st.write("Enter your skills and get predicted job role.")

@st.cache_resource
def load_model():
    tfidf = joblib.load("model/tfidf_vectorizer.pkl")
    model = joblib.load("model/job_role_model.pkl")
    return tfidf, model

tfidf, model = load_model()

skills_input = st.text_area(
    "Enter skills (comma separated)",
    placeholder="Example: python, sql, machine learning"
)

if st.button("Predict Job Role"):
    if not skills_input.strip():
        st.warning("Please enter some skills.")
    else:
        skills_clean = skills_input.lower().replace(",", " ")
        X_input = tfidf.transform([skills_clean])
        pred = model.predict(X_input)[0]
        st.success(f"✅ Predicted Job Role: **{pred}**")

st.markdown("### About")
st.write("This app predicts job role based on candidate skills using TF-IDF + ML model.")
st.info("Try: 'excel, tableau, power bi' or 'java, spring, mysql'")