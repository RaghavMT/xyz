// 1. Fake news data (you can edit this easily)
const stockNews = {
  TCS: [
    {
      title: "TCS wins multi-year cloud transformation deal from US bank",
      source: "Economic Times",
      timeAgo: "2 hours ago",
      impact: "positive",
      impactReason: "New large deal may boost revenue and investor sentiment."
    },
    {
      title: "Rupee volatility may impact IT margins, say analysts",
      source: "Moneycontrol",
      timeAgo: "1 day ago",
      impact: "neutral",
      impactReason: "Mixed margin impact; already factored into IT valuations."
    }
  ],
  RELIANCE: [
    {
      title: "Reliance Retail expands into new FMCG categories",
      source: "Business Standard",
      timeAgo: "4 hours ago",
      impact: "positive",
      impactReason: "Expansion could drive long-term growth in consumer segment."
    },
    {
      title: "Crude oil prices fall sharply in global markets",
      source: "Livemint",
      timeAgo: "1 day ago",
      impact: "positive",
      impactReason: "Lower crude prices usually improve refining margins."
    }
  ],
  HDFCBANK: [
    {
      title: "HDFC Bank reports strong growth in retail loan book",
      source: "CNBC TV18",
      timeAgo: "3 hours ago",
      impact: "positive",
      impactReason: "Loan book growth often leads to higher interest income."
    },
    {
      title: "RBI focuses on asset quality in latest circular",
      source: "Financial Express",
      timeAgo: "2 days ago",
      impact: "neutral",
      impactReason: "No direct negative signal but keeps spotlight on NPAs."
    }
  ],
  INFY: [
    {
      title: "Infosys signs partnership to build AI-powered solutions",
      source: "ET Tech",
      timeAgo: "5 hours ago",
      impact: "positive",
      impactReason: "AI focus may support higher-value deals and margins."
    },
    {
      title: "US recession fears weigh on IT sector outlook",
      source: "MarketWatch",
      timeAgo: "1 day ago",
      impact: "negative",
      impactReason: "Slowdown in client spending could delay new projects."
    }
  ]
};

// Get DOM elements
const stockSelect = document.getElementById("stockSelect");
const showNewsBtn = document.getElementById("showNewsBtn");
const newsContainer = document.getElementById("newsContainer");

// Map impact type to CSS class
function getImpactClass(impact) {
  if (impact === "positive") return "impact-positive";
  if (impact === "negative") return "impact-negative";
  return "impact-neutral";
}

// Render news for selected stock
function renderNewsForStock(stockSymbol) {
  const items = stockNews[stockSymbol] || [];
  newsContainer.innerHTML = "";

  if (items.length === 0) {
    newsContainer.innerHTML = "<p>No news available for this stock.</p>";
    return;
  }

  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "news-card";

    card.innerHTML = `
      <div class="news-title">${item.title}</div>
      <div class="news-meta">${item.source} • ${item.timeAgo}</div>
      <div class="news-impact ${getImpactClass(item.impact)}">
        Impact: ${item.impact.toUpperCase()} – ${item.impactReason}
      </div>
    `;

    newsContainer.appendChild(card);
  });
}

// Button click handler
showNewsBtn.addEventListener("click", () => {
  renderNewsForStock(stockSelect.value);
});

// Load default stock on start
renderNewsForStock(stockSelect.value);
