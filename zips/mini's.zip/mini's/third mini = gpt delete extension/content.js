console.log("ChatGPT Cleaner: content script loaded");

/* ------------------ constants ------------------ */

const DELETE_DELAY_MS = 1500;
const COUNTDOWN_STEP_MS = 100;
const BTN_ID = "cgpt-delete-current";

/* ------------------ helpers ------------------ */

function isTemporaryChat() {
  return window.location.search.includes("temporary-chat=true");
}

function isSavedChat() {
  return window.location.pathname.includes("/c/");
}

function findActiveMenu() {
  return document.querySelector('[role="menu"]');
}

/* ------------------ delete controller ------------------ */

const DeleteController = {
  state: "IDLE",
  timerId: null,

  start() {
    if (this.state !== "IDLE") return;
    this.state = "PENDING";
  },

  cancel(reason = "") {
    if (this.state !== "PENDING") return;
    clearTimeout(this.timerId);
    this.timerId = null;
    this.state = "IDLE";
    console.warn("Delete cancelled:", reason);
  },

  isPending() {
    return this.state === "PENDING";
  },

  startCountdown(onTick, onFinish) {
    let remaining = DELETE_DELAY_MS;

    const tick = () => {
      if (this.state !== "PENDING") return;

      remaining -= COUNTDOWN_STEP_MS;
      onTick(Math.max(remaining, 0));

      if (remaining <= 0) {
        this.timerId = null;
        onFinish();
      } else {
        this.timerId = setTimeout(tick, COUNTDOWN_STEP_MS);
      }
    };

    this.timerId = setTimeout(tick, COUNTDOWN_STEP_MS);
  }
};

/* ------------------ menu interaction ------------------ */

function openChatOptionsMenu() {
  const buttons = Array.from(document.querySelectorAll("button"));

  for (const btn of buttons) {
    const rect = btn.getBoundingClientRect();

    // must be visible
    if (rect.width === 0 || rect.height === 0) continue;
    if (btn.disabled) continue;

    // heuristic: menu buttons are usually square-ish
    if (rect.width > 60 || rect.height > 60) continue;

    // try click
    btn.click();

    // verify menu appeared
    if (findActiveMenu()) {
      console.log("Menu opened (verified)");
      return true;
    }
  }

  console.warn("Failed to open chat options menu");
  return false;
}

function clickDeleteMenuItem() {
  const menu = findActiveMenu();
  if (!menu) return false;

  const items = Array.from(menu.querySelectorAll('[role="menuitem"]'));
  for (const item of items) {
    if (item.textContent?.trim().toLowerCase() === "delete") {
      item.click();
      return true;
    }
  }
  return false;
}

/* ------------------ floating button ------------------ */

let positionDebounce = null;

function createFloatingButton() {
  let btn = document.getElementById(BTN_ID);
  if (btn) return btn;

  btn = document.createElement("button");
  btn.id = BTN_ID;
  btn.textContent = "Delete Chat";

  Object.assign(btn.style, {
    position: "fixed",
    zIndex: 2147483647,
    display: "none",
    padding: "8px 12px",
    borderRadius: "8px",
    border: "none",
    background: "#ef4444",
    color: "#fff",
    fontWeight: "600",
    cursor: "pointer"
  });

  btn.addEventListener("click", () => {
    if (DeleteController.isPending()) {
      DeleteController.cancel("user cancelled");
      btn.textContent = "Delete Chat";
      return;
    }

    DeleteController.start();
    btn.textContent = "STOP (1.5s)";

    DeleteController.startCountdown(
      ms => btn.textContent = `STOP (${(ms / 1000).toFixed(1)}s)`,
      () => {
        if (!openChatOptionsMenu()) {
          DeleteController.cancel("menu not opened");
          btn.textContent = "Delete Chat";
          return;
        }

        setTimeout(() => {
          if (!clickDeleteMenuItem()) {
            DeleteController.cancel("delete not found");
            btn.textContent = "Delete Chat";
          }
        }, 120);
      }
    );
  });

  document.body.appendChild(btn);
  return btn;
}

/* ------------------ positioning ------------------ */

function positionButton(btn, textarea) {
  const rect = textarea.getBoundingClientRect();
  btn.style.left = `${rect.right - 130}px`;
  btn.style.top = `${rect.bottom - 42}px`;
}

function debouncePosition() {
  if (positionDebounce) clearTimeout(positionDebounce);
  positionDebounce = setTimeout(() => {
    const btn = document.getElementById(BTN_ID);
    const textarea = document.querySelector("textarea");
    if (btn && textarea && btn.style.display !== "none") {
      positionButton(btn, textarea);
    }
  }, 80);
}

function showButton() {
  const textarea = document.querySelector("textarea");
  if (!textarea) return;

  const btn = createFloatingButton();
  positionButton(btn, textarea);
  btn.style.display = "block";
}

function hideButton() {
  const btn = document.getElementById(BTN_ID);
  if (btn) btn.style.display = "none";
}

/* ------------------ state evaluation ------------------ */

function evaluateState() {
  if (!isSavedChat() || isTemporaryChat()) {
    hideButton();
  } else {
    showButton();
  }
}

/* ------------------ observers ------------------ */

function startObservers() {
  let lastUrl = location.href;

  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      DeleteController.cancel("navigation");
      evaluateState();
    }
  }, 200);

  window.addEventListener("scroll", debouncePosition);
  window.addEventListener("resize", debouncePosition);
}

/* ------------------ init ------------------ */

function waitForUI() {
  const observer = new MutationObserver(() => {
    const textarea = document.querySelector("textarea");
    const sidebar = document.querySelector("nav");

    if (textarea && sidebar) {
      observer.disconnect();
      evaluateState();
      startObservers();
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

waitForUI();
