const jokeBtn = document.getElementById("jokeGen");
const jokeText = document.getElementById("jokeText");

jokeBtn.addEventListener("click", () => {
  fetch("https://official-joke-api.appspot.com/random_joke")
    .then(response => response.json())
    .then(data => {
      jokeText.textContent = data.setup + " — " + data.punchline;
    });
});
